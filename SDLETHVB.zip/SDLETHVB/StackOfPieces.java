package Players.SDLETHVB;

public class StackOfPieces {
	private Piece[] pieces;
	private final int SIZE = 4;
	
	/**
	 * constructs a StackOfPieces object.
	 */
	public StackOfPieces(){
		pieces = new Piece[SIZE];
	}
	/**
	 * inserts a new piece in the stack of pieces as desired.
	 * @param val
	 * @param ID
	 */
	public void setPiece(int val, int ID, int ourId){
		int idx=0;
		if(val == 4)
			idx=0;
		else if(val == 3)
			idx=1;
		else if(val == 2)
			idx=2;
		else if(val == 1)
			idx=3;
		if(ID==ourId){
			pieces[idx] = new Piece(val, true);
		}
		else if(ID!=ourId){
			pieces[idx] = new Piece(val, false);
		}
	}
	/**
	 * removes a piece from the stack and sets the value equal to null.
	 * @param val - the value piece being removed.
	 */
	public void removePiece(int val){
		if(val == 4)
			pieces[0]= null;
		else if(val == 3)
			pieces[1]= null;
		else if(val == 2)
			pieces[2]= null;
		else if(val == 1)
			pieces[3]= null;
	}
	/**
	 * gets the ID of the largest piece in the stack
	 * @return the ID of the largest piece in the stack, returns -1 if the stack is empty.
	 */
	public int getTopPieceID(int ourId){
		int count = 0;
		Piece p = null;
		
		while(count < 4){
			if(pieces[count] == null){
				count++;
			}
			else{
				p = pieces[count];
				break;
			}
			
		}
		if(p!=null){
			if(p.isOurPiece())
				return ourId;
			else{
				if(ourId==1)
					return 2;
				else
					return 1;
			}
		}
		return -1;
	}
	/**
	 * gets the largest piece in the stack
	 * @return the value of the largest piece in the stack, return -1 if the stack is empty.
	 */
	public int getTopVal(){
		int count = 0;
		while(count<4){
			if(pieces[count]!=null)
				return SIZE-count;
			count++;
		}
		return -1;
	}
	/**
	 * finds whether the stack is empty or not
	 * @return false if the stack has anything in it, returns true if the stack is empty.
	 */
	public boolean isEmpty(){
		for(int i = 0; i<SIZE; i++){
			if(pieces[i] != null)
				return false;
		}
		return true;
	}
	public Piece getTopPiece(){
		if(pieces[0]!=null)
			return pieces[0];
		if(pieces[1]!=null)
			return pieces[1];
		if(pieces[2]!=null)
			return pieces[2];
		if(pieces[3]!=null)
			return pieces[3];
		return null;
	}
}
