package Players.SDLETHVB;

public class Piece{
	private int value;
	private boolean isOurPiece;
	private boolean isBlocking;
	
	public Piece(int num,boolean isOurs){
		isBlocking = false;
		value = num;
		isOurPiece = isOurs;
	}
	public boolean isOurPiece(){
		return isOurPiece;
	}
	public void updateIsBlocking(){
		if(isBlocking)
			isBlocking = false;
		else 
			isBlocking = true;
	}
	public boolean isBlocking(){
		return isBlocking;
	}

}
