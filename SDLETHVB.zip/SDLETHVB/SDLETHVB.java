package Players.SDLETHVB;

import Engine.Logger;
import Interface.Coordinate;
import Interface.GobbletPart1;
import Interface.PlayerModule;
import Interface.PlayerMove;

public class SDLETHVB implements PlayerModule, GobbletPart1 {
	private Logger logger;
	private int playerId;
	private int otherplayerId;
	private Board board;

	@Override
	public void dumpGameState() {
		board.showGameState();
	}

	@Override
	public int getID() {
		return playerId;
	}

	@Override
	public int getTopOwnerOnBoard(int arg0, int arg1) {
		return board.getTopPlayerID(arg0, arg1);
	}

	@Override
	public int getTopSizeOnBoard(int arg0, int arg1) {
		return board.getTopValue(arg0,arg1);
	}

	@Override
	public int getTopSizeOnStack(int arg0, int arg1) {
		return board.biggestPieceInStack(arg0,arg1);
	}

	@Override
	public void init(Logger logger, int playerId) {
		this.logger = logger;
		this.playerId = playerId;
		if (playerId == 1) {
			otherplayerId = 2;
		}
		else {
			otherplayerId = 1;
		}
		board = new Board(playerId);
	}

	@Override
	public void lastMove(PlayerMove arg0){
		board.updateBoard(arg0);
		dumpGameState();
	}

	@Override
	public PlayerMove move() {
//		if(board.win()!=null)
//			return board.win();
		Coordinate end = board.getEmptySpace();
		Coordinate block = board.placeToBlock(otherplayerId);
		int stack = board.getStackWithLargestPiece();
		if (board.getLargestPiece() != 4) {
			stack = 0;
		}
		if (block != null) { //need to block somewhere
			if(board.getTopValue(block.getRow(), block.getCol())==-1){
				return new PlayerMove(playerId, 0, 4, board.getPieceOnBoard(4, playerId),block ); //always place a piece size 4 in the empty space.
			}
			else{
				Coordinate pieceToMove = board.getPieceOnBoard(board.getTopValue(block.getRow(), block.getCol())+1,playerId);
				if(pieceToMove==null){ // only occurs when the piece was a size 1 or 2 and tried to find a 2 or 3 and couldn't
					pieceToMove = board.getPieceOnBoard(3,playerId);//if the piece was a 1, try to look for a 3
					if(pieceToMove!=null){
						return new PlayerMove(playerId, 0, 3, pieceToMove, block);
					}
					pieceToMove = board.getPieceOnBoard(4, playerId);
				}
				return new PlayerMove(playerId, 0, board.getTopValue(pieceToMove.getRow(), pieceToMove.getCol()), pieceToMove, block);
			}
		}
		if(end==null){
			Coordinate start = board.getPieceOnBoard(4, playerId);
			//when board is full, use the first size 4 piece to gobble one of their smaller pieces.
			for(int i = 3; i>0; i--){
				if(board.getPieceOnBoard(i, otherplayerId)!= null)
					end = board.getPieceOnBoard(i, otherplayerId);
			}
			return new PlayerMove(playerId, 0, 4, start, end);
		}

		return new PlayerMove(playerId, board.getStackWithLargestPiece(), board.getLargestPiece(),
				new Coordinate(-1, -1), end);
	}

	@Override
	public void playerInvalidated(int arg0) {
		// TODO Auto-generated method stub

	}
//	win method with any piece and gobble to win
//	checkLose method when removing piece
//	modify block method to block with four


}
