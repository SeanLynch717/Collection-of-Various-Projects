package Players.SDLETHVB;

import java.util.ArrayList;

import Interface.Coordinate;
import Interface.PlayerMove;

public class Board {
	private final int SIZE = 4;
	private StackOfPieces[][] board;
	private StackOfPieces[] ours;
	private StackOfPieces[] theirs;
	private int ourId;
	private int theirId;

	/**
	 * constructs a Board object to have a 2D array of StackOfPieces and 2 arrays of StackOfPieces to contain the initial
	 * pieces off the board.
	 */
	public Board(int ourId){
		board = new StackOfPieces[4][4];
		ours = new StackOfPieces[3];
		theirs = new StackOfPieces[3];
		this.ourId = ourId;
		if (ourId == 1) {
			theirId = 2;
		}
		else {
			theirId = 1;
		}

		for(int r = 0; r<SIZE; r++){
			for(int c = 0; c<SIZE; c++){
				board[r][c]=new StackOfPieces();
			}
		}

		for(int i=0; i<3;i++){
			ours[i]=new StackOfPieces();
			theirs[i]=new StackOfPieces();
		}
		for(int i=0; i<3; i++){
			ours[i].setPiece(4, ourId, ourId);
			ours[i].setPiece(3, ourId, ourId);
			ours[i].setPiece(2, ourId, ourId);
			ours[i].setPiece(1, ourId, ourId);
			theirs[i].setPiece(4, ourId, theirId);
			theirs[i].setPiece(3, ourId, theirId);
			theirs[i].setPiece(2, ourId, theirId);
			theirs[i].setPiece(1, ourId, theirId);
		}

	}
	/**
	 * 
	 * @return
	 */
	public int getSIZE() {
		return SIZE;
	}
	/**
	 * gets the ID of the top most player
	 * @param row - the row
	 * @param col - the column
	 * @return the ID of the top most player in the stack
	 */
	public int getTopPlayerID(int row, int col){
		return board[row][col].getTopPieceID(ourId);
	}
	/**
	 * gets the value of the top most piece
	 * @param row - the row
	 * @param col - the col
	 * @return the value of the highest piece in the stack
	 */
	public int getTopValue(int row, int col){
		return board[row][col].getTopVal();
	}
	/**
	 * updates the board based on the prev move
	 * @param p the prev move
	 */
	public void updateBoard(PlayerMove p){
		System.out.println("enters updateBoard");
		int stackNum = p.getStack();
		int ID = p.getPlayerId();
		int size = p.getSize();
		int sRow = p.getStartRow();
		int sCol = p.getStartCol();
		int eRow = p.getEndRow();
		int eCol = p.getEndCol();
		if(stackNum!=0){
			if(ID==ourId){
				ours[stackNum-1].removePiece(size);
			}
			else
				theirs[stackNum-1].removePiece(size);
			board[eRow][eCol].setPiece(size,ID, ourId);
		}
		else{
			board[sRow][sCol].removePiece(size);
			board[eRow][eCol].setPiece(size, ID, ourId);
		}
	}
	/**
	 * finds the biggest piece in the stack
	 * @param playerID id of the piece ( if ours or theirs)
	 * @param stackNum the stack off the board
	 * @return the biggest value in the stack
	 */
	public int biggestPieceInStack(int playerID, int stackNum){
		if(playerID == ourId){
			return ours[stackNum-1].getTopVal();
		}
		else{
			return theirs[stackNum-1].getTopVal();
		}
	}
	/**
	 * displays the current state of the board.
	 */
	public void showGameState(){
		for(int row=0; row<SIZE; row++){
			for(int col=0; col<SIZE; col++){
				if(board[row][col].getTopVal()==-1){
					System.out.print("[]   ");
				}
				else{
					System.out.print(board[row][col].getTopVal() +"(" +board[row][col].getTopPieceID(ourId) +") ");
				}
			}
			if(row==0){
				if(ours[0].getTopVal()==-1)
					System.out.print("  _ ");
				else
					System.out.print("  " +ours[0].getTopVal() +" ");
				if(ours[1].getTopVal()==-1)
					System.out.print("_ ");
				else
					System.out.print(ours[1].getTopVal() +" ");
				if(ours[2].getTopVal()==-1)
					System.out.print("_ ");
				else
					System.out.print(ours[2].getTopVal() +" ");
			}
			if(row == 2){
				if(theirs[0].getTopVal()==-1)
					System.out.print("  _ ");
				else
					System.out.print("  " +theirs[0].getTopVal() +" ");
				if(theirs[1].getTopVal()==-1)
					System.out.print("_ ");
				else
					System.out.print(theirs[1].getTopVal() +" ");
				if(theirs[2].getTopVal()==-1)
					System.out.print("_ ");
				else
					System.out.print(theirs[2].getTopVal() +" ");
			}
			System.out.println();
		}
	}
	/**
	 * gets the first empty space in board
	 * @return the coordinate of the first empty space, returning null if there aren't any.
	 */
	public Coordinate getEmptySpace(){
		ArrayList<Coordinate> coords = new ArrayList<Coordinate>();
		for(int r = 0; r<SIZE; r++){
			for(int c = 0; c<SIZE; c++){
				if(board[r][c].getTopVal()==-1){
					coords.add(new Coordinate(r,c));
				}
			}
		}
		if(coords.size()>0)
			return coords.get((int)(Math.random()*coords.size()));
		return null;
	}
	/**
	 * gets the number stack where the largest piece is found.
	 * @return - the stack number with the largest piece
	 */
	public int getStackWithLargestPiece() {
		int s = 1;
		int largeNum = ours[0].getTopVal();
		for (int i=1; i<3; i++) {
			if (ours[i].getTopVal() > largeNum) {
				s = i+1;
				largeNum = ours[i].getTopVal();
			}
		}
		if (largeNum != -1) {
			return s;
		}
		return -1;
	}
	/**
	 * gets the largest piece from the stack with the largest piece. 
	 * @return the value of the piece, -1 if there aren't any stacks left off the board.
	 */
	public int getLargestPiece() {
		if(getStackWithLargestPiece()==-1){
			return -1;
		}
		return ours[getStackWithLargestPiece()-1].getTopVal();
	}
	/**
	 * 
	 * @param val - the value of the piece 
	 * @param ID - the playerID of the piece
	 * @return - the coordinate of the piece.
	 */
	public Coordinate getPieceOnBoard(int val, int ID){
		for(int r = 0; r<SIZE; r++){
			for(int c = 0; c<SIZE; c++){
				if(board[r][c].getTopVal()==val && board[r][c].getTopPieceID(ourId)==ID)
					return new Coordinate(r,c);
			}
		}
		return null;
	}

		
	/**
	 * finds the first place that needs to be blocked
	 * @return the coordinate that needs to be blocked
	 */
	public Coordinate placeToBlock(int id){
		int row = check3Row(id);
		int col = check3Col(id);
		if(row>-1){
			return getPlaceToBeBlockedRow(row);
		}
		if(col>-1){
			return getPlaceToBeBlockedCol(col);
		}
		return getPlaceToBeBlockedDiagonal();
	}
	/**
	 * checks each row for 3 pieces of given id
	 * @return int of the row where there is 3, -1 if no 3s
	 */
	public int check3Row(int id){
		int theirCount = 0;
		for(int r=0; r<SIZE;r++){
			for(int c=0; c<SIZE; c++){
				if(board[r][c].getTopPieceID(ourId)== id){
					theirCount++;
				}
			}
			if(theirCount == 3){
				return r;
			}
			theirCount = 0;
		}
		return -1;
	}
	
	/**
	 * checks each col for 3 pieces of given id
	 * @return int of the col where there is 3, -1 if no 3s
	 */
	public int check3Col(int id){
		int theirCount = 0;
		for(int c=0; c<SIZE;c++){
			for(int r=0; r<SIZE; r++){
				if(board[r][c].getTopPieceID(ourId) == id){
					theirCount++;
				}
			}
			if(theirCount == 3){
				return c;
			}
			theirCount = 0;
		}
		return -1;
	}
	/**
	 * gets an empty space to block, or a space with a piece value 3 or less so we can gobble it
	 * @param row - number row
	 * @return a coordinate that needs to be blocked
	 */
	public Coordinate getPlaceToBeBlockedRow(int row){
		Coordinate possibleGobble = null;
		for(int c=0;c<SIZE;c++){
			if(board[row][c].getTopPieceID(ourId)==theirId && board[row][c].getTopVal()<4){
				possibleGobble = new Coordinate(row,c);
			}
			if(board[row][c].getTopPieceID(ourId)==ourId && board[row][c].getTopVal()==4){
				possibleGobble =null;
				break;
			}
		}
		if(possibleGobble!=null){
			return possibleGobble;
		}
		for(int c=0; c<SIZE; c++){
			if(board[row][c].getTopVal()==-1)
				return new Coordinate(row,c);
		}
		return null;
	}
	/**
	 * gets an empty space to block, or a space with a piece value 3 or less so we can gobble it
	 * @param col - number col
	 * @return the coordinate needs to be blocked
	 */
	public Coordinate getPlaceToBeBlockedCol(int col){
		Coordinate possibleGobble = null;
		for(int r=0;r<SIZE;r++){
			if(board[r][col].getTopPieceID(ourId)==theirId && board[r][col].getTopVal()<4){
				possibleGobble = new Coordinate(r,col);
			}
			if(board[r][col].getTopPieceID(ourId)==ourId && board[r][col].getTopVal()==4){
				possibleGobble =null;
				break;
			}
		}
		if(possibleGobble!=null){
			return possibleGobble;
		}
		for(int r=0; r<SIZE; r++){
			if(board[r][col].getTopVal()==-1)
				return new Coordinate(r,col);
		}
		return null;
	}
	/**
	 * checks if there is a diagonal with 3 of the same pieces
	 * @param id - the id of the player checking
	 * @return 0 if the diagonal goes from top left to bottom right, 3 if the diagonal goes from bottom left to top right and -1 if there are no 3 in a diagonal.
	 */
	public int checkDiagonals(int id){
		int count=0;
		for(int i = 0; i<SIZE; i++){
			if(board[i][i].getTopPieceID(ourId) == id) {
				count++;
			}
		}
		if(count==3){
			return 0;
		}
		count=0;
		for(int i = 0; i<SIZE; i++){
			if(board[3-i][i].getTopPieceID(ourId) == id){
				count++;
			}	
		}
		if(count==3){
			return 3;
		}
		return -1;
	}
	/**
	 * gets the place, if any, in a diagonal that needs to be blocked
	 * @return the coordinate of the place to be blocked, null if there isn't. It needs to be blocked if there isn't a piece there, or a piece smaller than 4 is there.
	 */
	public Coordinate getPlaceToBeBlockedDiagonal(){
		int topLeft = checkDiagonals(theirId);
		int bottomLeft = checkDiagonals(theirId);
		if(topLeft==-1 && bottomLeft==-1)
			return null;
		if(topLeft==0){
			for(int i = 0; i<SIZE; i++){
				if((board[i][i].getTopPieceID(ourId)==theirId && board[i][i].getTopVal()<4) || (board[i][i].getTopVal()==-1))
					return new Coordinate(i,i);
				
			}
		}
		if(bottomLeft==3){
			for(int i = 0; i<SIZE; i++){
				if((board[3-i][i].getTopPieceID(ourId)==theirId && board[3-i][i].getTopVal()<4) || (board[3-i][i].getTopVal()==-1))
					return new Coordinate(3-i,i);
			}
		}
		return null;
		
	}
	
	/**
	 * finds Coordinate of the piece we are using to block
	 * 
	 * DONT FORGET TO CHECK SIZE OF PIECE (IF A SMALL PIECE)
	 * 
	 * @return the Coordinate of the piece
	 */
	public Coordinate pieceToBlock(){
		if(ours[0].getTopVal() == 4 || ours[1].getTopVal() == 4 || ours[2].getTopVal() == 4){
			return new Coordinate(-1,-1);
		}
		
		for(int r=0; r<SIZE;r++){
			for(int c=0; c<SIZE; c++){
				if(board[r][c].getTopVal() == 4 && board[r][c].getTopPieceID(ourId) == ourId){
					return new Coordinate(r,c);
				}
			}
		}
		return null;
	}
	/**
	 * PreCondition: the size of the top piece at coord is at most 3.
	 * gets the size piece we need to gobble a certain piece
	 * @param coord the coordinate of the piece we're gobbling
	 * @return the size of the piece needed to gobble the specific piece.
	 */
	public int getSizePieceNeededToGobble(Coordinate coord){
		return board[coord.getRow()][coord.getCol()].getTopVal() +1;
	}
	/**
	 * Checks if our player has a winning move
	 * @return the player move that will let us win the game!
	 */
//	public PlayerMove win(){
//		ArrayList<Coordinate> coords = new ArrayList<Coordinate>();
//		int row = check3Row(ourId);
//		int col = check3Col(ourId);
//		int diag = checkDiagonals(ourId);
//		if(row==-1 && col==-1 && diag==-1)
//			return null;
//		if (row>-1){
//			for(int i=0; i<SIZE;i++){
//				if(board[row][i].getTopPieceID(ourId)==ourId){
//					coords.add(new Coordinate(row,i));
//				}
//			}
//		}
//		else if(col>-1){
//			for(int i=0; i<SIZE;i++){
//				if(board[i][col].getTopPieceID(ourId)==ourId){
//					coords.add(new Coordinate(i,col));
//				}
//			}
//		}
//		else if(diag==0){
//			for(int i=0; i<SIZE;i++){
//				if(board[i][i].getTopPieceID(ourId)==ourId){
//					coords.add(new Coordinate(i,i));
//				}
//			}
//		}
//		else{
//			for(int i=0; i<SIZE;i++){
//				if(board[3-i][i].getTopPieceID(ourId)==ourId){
//					coords.add(new Coordinate(3-i,i));
//				}
//			}
//		}
//			
//	}
}